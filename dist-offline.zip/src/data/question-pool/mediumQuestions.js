/* Generated from content/questions/medium.json. */
(function (global) {
  "use strict";
  global.QuestionPoolParts = global.QuestionPoolParts || {};
  global.QuestionPoolParts.medium = [
  {
    "id": "color_medium_001",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点红色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "red",
        "label": "红色",
        "color": "#FF3D5A"
      },
      {
        "id": "blue",
        "label": "蓝色",
        "color": "#3483FF"
      },
      {
        "id": "green",
        "label": "绿色",
        "color": "#00FF9D"
      }
    ],
    "correctAction": "blue",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_002",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点黄色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "yellow",
        "label": "黄色",
        "color": "#FFD600"
      },
      {
        "id": "purple",
        "label": "紫色",
        "color": "#A855F7"
      },
      {
        "id": "blue",
        "label": "蓝色",
        "color": "#3483FF"
      }
    ],
    "correctAction": "purple",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_003",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点绿色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "green",
        "label": "绿色",
        "color": "#00FF9D"
      },
      {
        "id": "orange",
        "label": "橙色",
        "color": "#FF8A00"
      },
      {
        "id": "pink",
        "label": "粉色",
        "color": "#FF5CB0"
      }
    ],
    "correctAction": "orange",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_004",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点黑色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "black",
        "label": "黑色",
        "color": "#000000"
      },
      {
        "id": "white",
        "label": "白色",
        "color": "#FFFFFF"
      },
      {
        "id": "gray",
        "label": "灰色",
        "color": "#8E8E8E"
      }
    ],
    "correctAction": "white",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_005",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点青色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "cyan",
        "label": "青色",
        "color": "#00FFC7"
      },
      {
        "id": "pink",
        "label": "粉色",
        "color": "#FF5CB0"
      },
      {
        "id": "yellow",
        "label": "黄色",
        "color": "#FFD600"
      }
    ],
    "correctAction": "pink",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_006",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点红色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "red",
        "label": "红色",
        "color": "#FF3D5A"
      },
      {
        "id": "green",
        "label": "绿色",
        "color": "#00FF9D"
      },
      {
        "id": "blue",
        "label": "蓝色",
        "color": "#3483FF"
      }
    ],
    "correctAction": "green",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_007",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点黄色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "yellow",
        "label": "黄色",
        "color": "#FFD600"
      },
      {
        "id": "blue",
        "label": "蓝色",
        "color": "#3483FF"
      },
      {
        "id": "white",
        "label": "白色",
        "color": "#FFFFFF"
      }
    ],
    "correctAction": "blue",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_008",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点紫色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "purple",
        "label": "紫色",
        "color": "#A855F7"
      },
      {
        "id": "orange",
        "label": "橙色",
        "color": "#FF8A00"
      },
      {
        "id": "green",
        "label": "绿色",
        "color": "#00FF9D"
      }
    ],
    "correctAction": "orange",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_009",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点黑色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "black",
        "label": "黑色",
        "color": "#000000"
      },
      {
        "id": "cyan",
        "label": "青色",
        "color": "#00FFC7"
      },
      {
        "id": "red",
        "label": "红色",
        "color": "#FF3D5A"
      }
    ],
    "correctAction": "cyan",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_010",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点白色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "white",
        "label": "白色",
        "color": "#FFFFFF"
      },
      {
        "id": "pink",
        "label": "粉色",
        "color": "#FF5CB0"
      },
      {
        "id": "purple",
        "label": "紫色",
        "color": "#A855F7"
      }
    ],
    "correctAction": "pink",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_011",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点绿色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "green",
        "label": "绿色",
        "color": "#00FF9D"
      },
      {
        "id": "purple",
        "label": "紫色",
        "color": "#A855F7"
      },
      {
        "id": "blue",
        "label": "蓝色",
        "color": "#3483FF"
      }
    ],
    "correctAction": "purple",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_012",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点蓝色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "blue",
        "label": "蓝色",
        "color": "#3483FF"
      },
      {
        "id": "orange",
        "label": "橙色",
        "color": "#FF8A00"
      },
      {
        "id": "yellow",
        "label": "黄色",
        "color": "#FFD600"
      }
    ],
    "correctAction": "orange",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_013",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点红色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "red",
        "label": "红色",
        "color": "#FF3D5A"
      },
      {
        "id": "yellow",
        "label": "黄色",
        "color": "#FFD600"
      },
      {
        "id": "pink",
        "label": "粉色",
        "color": "#FF5CB0"
      }
    ],
    "correctAction": "yellow",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_014",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点粉色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "pink",
        "label": "粉色",
        "color": "#FF5CB0"
      },
      {
        "id": "purple",
        "label": "紫色",
        "color": "#A855F7"
      },
      {
        "id": "orange",
        "label": "橙色",
        "color": "#FF8A00"
      }
    ],
    "correctAction": "purple",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_015",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点青色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "cyan",
        "label": "青色",
        "color": "#00FFC7"
      },
      {
        "id": "green",
        "label": "绿色",
        "color": "#00FF9D"
      },
      {
        "id": "pink",
        "label": "粉色",
        "color": "#FF5CB0"
      }
    ],
    "correctAction": "green",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_016",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点橙色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "orange",
        "label": "橙色",
        "color": "#FF8A00"
      },
      {
        "id": "black",
        "label": "黑色",
        "color": "#000000"
      },
      {
        "id": "yellow",
        "label": "黄色",
        "color": "#FFD600"
      }
    ],
    "correctAction": "black",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_017",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点白色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "white",
        "label": "白色",
        "color": "#FFFFFF"
      },
      {
        "id": "blue",
        "label": "蓝色",
        "color": "#3483FF"
      },
      {
        "id": "black",
        "label": "黑色",
        "color": "#000000"
      }
    ],
    "correctAction": "blue",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_018",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点蓝色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "blue",
        "label": "蓝色",
        "color": "#3483FF"
      },
      {
        "id": "black",
        "label": "黑色",
        "color": "#000000"
      },
      {
        "id": "orange",
        "label": "橙色",
        "color": "#FF8A00"
      }
    ],
    "correctAction": "black",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_019",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点粉色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "pink",
        "label": "粉色",
        "color": "#FF5CB0"
      },
      {
        "id": "green",
        "label": "绿色",
        "color": "#00FF9D"
      },
      {
        "id": "yellow",
        "label": "黄色",
        "color": "#FFD600"
      }
    ],
    "correctAction": "green",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_020",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点紫色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "purple",
        "label": "紫色",
        "color": "#A855F7"
      },
      {
        "id": "pink",
        "label": "粉色",
        "color": "#FF5CB0"
      },
      {
        "id": "cyan",
        "label": "青色",
        "color": "#00FFC7"
      }
    ],
    "correctAction": "pink",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_021",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点绿色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "green",
        "label": "绿色",
        "color": "#00FF9D"
      },
      {
        "id": "pink",
        "label": "粉色",
        "color": "#FF5CB0"
      },
      {
        "id": "orange",
        "label": "橙色",
        "color": "#FF8A00"
      }
    ],
    "correctAction": "pink",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_022",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点黄色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "yellow",
        "label": "黄色",
        "color": "#FFD600"
      },
      {
        "id": "green",
        "label": "绿色",
        "color": "#00FF9D"
      },
      {
        "id": "cyan",
        "label": "青色",
        "color": "#00FFC7"
      }
    ],
    "correctAction": "green",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_023",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点白色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "white",
        "label": "白色",
        "color": "#FFFFFF"
      },
      {
        "id": "black",
        "label": "黑色",
        "color": "#000000"
      },
      {
        "id": "cyan",
        "label": "青色",
        "color": "#00FFC7"
      }
    ],
    "correctAction": "black",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_024",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点蓝色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "blue",
        "label": "蓝色",
        "color": "#3483FF"
      },
      {
        "id": "pink",
        "label": "粉色",
        "color": "#FF5CB0"
      },
      {
        "id": "purple",
        "label": "紫色",
        "color": "#A855F7"
      }
    ],
    "correctAction": "pink",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_medium_025",
    "type": "color",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点黑色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "black",
        "label": "黑色",
        "color": "#000000"
      },
      {
        "id": "green",
        "label": "绿色",
        "color": "#00FF9D"
      },
      {
        "id": "purple",
        "label": "紫色",
        "color": "#A855F7"
      }
    ],
    "correctAction": "green",
    "timeLimit": 1100,
    "trap": "颜色干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "color_stroop_medium_026",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "红色",
    "fontColor": "#3483FF",
    "options": [
      {
        "id": "btn_1",
        "label": "红色",
        "color": "#3483FF",
        "textColor": "#FF3D5A"
      },
      {
        "id": "btn_2",
        "label": "蓝色",
        "color": "#FF3D5A",
        "textColor": "#3483FF"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_027",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "黄色",
    "fontColor": "#00FF9D",
    "options": [
      {
        "id": "btn_1",
        "label": "黄色",
        "color": "#00FF9D",
        "textColor": "#FFD600"
      },
      {
        "id": "btn_2",
        "label": "绿色",
        "color": "#FFD600",
        "textColor": "#00FF9D"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_028",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "紫色",
    "fontColor": "#FF8A00",
    "options": [
      {
        "id": "btn_1",
        "label": "紫色",
        "color": "#FF8A00",
        "textColor": "#A855F7"
      },
      {
        "id": "btn_2",
        "label": "橙色",
        "color": "#A855F7",
        "textColor": "#FF8A00"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_029",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "黑色",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "黑色",
        "color": "#FFFFFF",
        "textColor": "#000000"
      },
      {
        "id": "btn_2",
        "label": "白色",
        "color": "#000000",
        "textColor": "#FFFFFF"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_030",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "青色",
    "fontColor": "#FF5CB0",
    "options": [
      {
        "id": "btn_1",
        "label": "青色",
        "color": "#FF5CB0",
        "textColor": "#00FFC7"
      },
      {
        "id": "btn_2",
        "label": "粉色",
        "color": "#00FFC7",
        "textColor": "#FF5CB0"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_031",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "粉色",
    "fontColor": "#3483FF",
    "options": [
      {
        "id": "btn_1",
        "label": "粉色",
        "color": "#3483FF",
        "textColor": "#FF5CB0"
      },
      {
        "id": "btn_2",
        "label": "蓝色",
        "color": "#FF5CB0",
        "textColor": "#3483FF"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_032",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "黄色",
    "fontColor": "#FF3D5A",
    "options": [
      {
        "id": "btn_1",
        "label": "黄色",
        "color": "#FF3D5A",
        "textColor": "#FFD600"
      },
      {
        "id": "btn_2",
        "label": "红色",
        "color": "#FFD600",
        "textColor": "#FF3D5A"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_033",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "绿色",
    "fontColor": "#A855F7",
    "options": [
      {
        "id": "btn_1",
        "label": "绿色",
        "color": "#A855F7",
        "textColor": "#00FF9D"
      },
      {
        "id": "btn_2",
        "label": "紫色",
        "color": "#00FF9D",
        "textColor": "#A855F7"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_034",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "红色",
    "fontColor": "#FF8A00",
    "options": [
      {
        "id": "btn_1",
        "label": "红色",
        "color": "#FF8A00",
        "textColor": "#FF3D5A"
      },
      {
        "id": "btn_2",
        "label": "橙色",
        "color": "#FF3D5A",
        "textColor": "#FF8A00"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_035",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "蓝色",
    "fontColor": "#FFD600",
    "options": [
      {
        "id": "btn_1",
        "label": "蓝色",
        "color": "#FFD600",
        "textColor": "#3483FF"
      },
      {
        "id": "btn_2",
        "label": "黄色",
        "color": "#3483FF",
        "textColor": "#FFD600"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_036",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "紫色",
    "fontColor": "#00FFC7",
    "options": [
      {
        "id": "btn_1",
        "label": "紫色",
        "color": "#00FFC7",
        "textColor": "#A855F7"
      },
      {
        "id": "btn_2",
        "label": "青色",
        "color": "#A855F7",
        "textColor": "#00FFC7"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_037",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "白色",
    "fontColor": "#FF5CB0",
    "options": [
      {
        "id": "btn_1",
        "label": "白色",
        "color": "#FF5CB0",
        "textColor": "#FFFFFF"
      },
      {
        "id": "btn_2",
        "label": "粉色",
        "color": "#FFFFFF",
        "textColor": "#FF5CB0"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_038",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "青色",
    "fontColor": "#FFD600",
    "options": [
      {
        "id": "btn_1",
        "label": "青色",
        "color": "#FFD600",
        "textColor": "#00FFC7"
      },
      {
        "id": "btn_2",
        "label": "黄色",
        "color": "#00FFC7",
        "textColor": "#FFD600"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_039",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "蓝色",
    "fontColor": "#FF3D5A",
    "options": [
      {
        "id": "btn_1",
        "label": "蓝色",
        "color": "#FF3D5A",
        "textColor": "#3483FF"
      },
      {
        "id": "btn_2",
        "label": "红色",
        "color": "#3483FF",
        "textColor": "#FF3D5A"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_040",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "黑色",
    "fontColor": "#00FF9D",
    "options": [
      {
        "id": "btn_1",
        "label": "黑色",
        "color": "#00FF9D",
        "textColor": "#000000"
      },
      {
        "id": "btn_2",
        "label": "绿色",
        "color": "#000000",
        "textColor": "#00FF9D"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_041",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "粉色",
    "fontColor": "#A855F7",
    "options": [
      {
        "id": "btn_1",
        "label": "粉色",
        "color": "#A855F7",
        "textColor": "#FF5CB0"
      },
      {
        "id": "btn_2",
        "label": "紫色",
        "color": "#FF5CB0",
        "textColor": "#A855F7"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_042",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "绿色",
    "fontColor": "#FF8A00",
    "options": [
      {
        "id": "btn_1",
        "label": "绿色",
        "color": "#FF8A00",
        "textColor": "#00FF9D"
      },
      {
        "id": "btn_2",
        "label": "橙色",
        "color": "#00FF9D",
        "textColor": "#FF8A00"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_043",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "白色",
    "fontColor": "#3483FF",
    "options": [
      {
        "id": "btn_1",
        "label": "白色",
        "color": "#3483FF",
        "textColor": "#FFFFFF"
      },
      {
        "id": "btn_2",
        "label": "蓝色",
        "color": "#FFFFFF",
        "textColor": "#3483FF"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_044",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "青色",
    "fontColor": "#FF3D5A",
    "options": [
      {
        "id": "btn_1",
        "label": "青色",
        "color": "#FF3D5A",
        "textColor": "#00FFC7"
      },
      {
        "id": "btn_2",
        "label": "红色",
        "color": "#00FFC7",
        "textColor": "#FF3D5A"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_045",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "蓝色",
    "fontColor": "#00FFC7",
    "options": [
      {
        "id": "btn_1",
        "label": "蓝色",
        "color": "#00FFC7",
        "textColor": "#3483FF"
      },
      {
        "id": "btn_2",
        "label": "青色",
        "color": "#3483FF",
        "textColor": "#00FFC7"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_046",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "红色",
    "fontColor": "#00FF9D",
    "options": [
      {
        "id": "btn_1",
        "label": "红色",
        "color": "#00FF9D",
        "textColor": "#FF3D5A"
      },
      {
        "id": "btn_2",
        "label": "绿色",
        "color": "#FF3D5A",
        "textColor": "#00FF9D"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_047",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "黄色",
    "fontColor": "#3483FF",
    "options": [
      {
        "id": "btn_1",
        "label": "黄色",
        "color": "#3483FF",
        "textColor": "#FFD600"
      },
      {
        "id": "btn_2",
        "label": "蓝色",
        "color": "#FFD600",
        "textColor": "#3483FF"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_048",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "紫色",
    "fontColor": "#00FF9D",
    "options": [
      {
        "id": "btn_1",
        "label": "紫色",
        "color": "#00FF9D",
        "textColor": "#A855F7"
      },
      {
        "id": "btn_2",
        "label": "绿色",
        "color": "#A855F7",
        "textColor": "#00FF9D"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_049",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "白色",
    "fontColor": "#FFD600",
    "options": [
      {
        "id": "btn_1",
        "label": "白色",
        "color": "#FFD600",
        "textColor": "#FFFFFF"
      },
      {
        "id": "btn_2",
        "label": "黄色",
        "color": "#FFFFFF",
        "textColor": "#FFD600"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "color_stroop_medium_050",
    "type": "color_stroop",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "青色",
    "fontColor": "#A855F7",
    "options": [
      {
        "id": "btn_1",
        "label": "青色",
        "color": "#A855F7",
        "textColor": "#00FFC7"
      },
      {
        "id": "btn_2",
        "label": "紫色",
        "color": "#00FFC7",
        "textColor": "#A855F7"
      }
    ],
    "correctAction": "btn_2",
    "timeLimit": 1100,
    "trap": "Stroop干扰",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "direction_medium_051",
    "type": "direction",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点击左边",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_right",
    "timeLimit": 1100,
    "trap": "方向反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "direction_medium_052",
    "type": "direction",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点击右边",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_left",
    "timeLimit": 1100,
    "trap": "方向反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "direction_medium_053",
    "type": "direction",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点击顶部",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_bottom",
    "timeLimit": 1100,
    "trap": "方向反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "direction_medium_054",
    "type": "direction",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点击底部",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_top",
    "timeLimit": 1100,
    "trap": "方向反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "direction_medium_055",
    "type": "direction",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点击左侧按钮",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_right",
    "timeLimit": 1100,
    "trap": "方向反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "direction_medium_056",
    "type": "direction",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点击右侧按钮",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_left",
    "timeLimit": 1100,
    "trap": "方向反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "direction_medium_057",
    "type": "direction",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点击上边按钮",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_bottom",
    "timeLimit": 1100,
    "trap": "方向反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "direction_medium_058",
    "type": "direction",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点击下边按钮",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_top",
    "timeLimit": 1100,
    "trap": "方向反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "direction_medium_059",
    "type": "direction",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点左边",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_right",
    "timeLimit": 1100,
    "trap": "方向反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "direction_medium_060",
    "type": "direction",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点右边",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_left",
    "timeLimit": 1100,
    "trap": "方向反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P0"
  },
  {
    "id": "double_negative_medium_061",
    "type": "double_negative",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "不要不点",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "wait",
    "timeLimit": 1100,
    "trap": "双重否定",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "double_negative_medium_062",
    "type": "double_negative",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "别不向左滑",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "swipe_right",
    "timeLimit": 1100,
    "trap": "双重否定",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "double_negative_medium_063",
    "type": "double_negative",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "别不向右滑",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "swipe_left",
    "timeLimit": 1100,
    "trap": "双重否定",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "double_negative_medium_064",
    "type": "double_negative",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "别不向上滑",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "swipe_down",
    "timeLimit": 1100,
    "trap": "双重否定",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "double_negative_medium_065",
    "type": "double_negative",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "别不向下滑",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "swipe_up",
    "timeLimit": 1100,
    "trap": "双重否定",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "double_negative_medium_066",
    "type": "double_negative",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "不要不选左边",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_right",
    "timeLimit": 1100,
    "trap": "双重否定",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "double_negative_medium_067",
    "type": "double_negative",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "不要不选右边",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_left",
    "timeLimit": 1100,
    "trap": "双重否定",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "double_negative_medium_068",
    "type": "double_negative",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "禁止不停下",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "wait",
    "timeLimit": 1100,
    "trap": "双重否定",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "double_negative_medium_069",
    "type": "double_negative",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "别不向右点",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_left",
    "timeLimit": 1100,
    "trap": "双重否定",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "double_negative_medium_070",
    "type": "double_negative",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "别不向左点",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "click_right",
    "timeLimit": 1100,
    "trap": "双重否定",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "action_medium_071",
    "type": "action",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "快点一下",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "long_press",
    "timeLimit": 1100,
    "trap": "动作克制",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "action_medium_072",
    "type": "action",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "长按一下",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "quick_tap",
    "timeLimit": 1100,
    "trap": "动作克制",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "action_medium_073",
    "type": "action",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "别点",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "tap",
    "timeLimit": 1100,
    "trap": "动作反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "action_medium_074",
    "type": "action",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "别快点",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "quick_tap",
    "timeLimit": 1100,
    "trap": "动作反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "action_medium_075",
    "type": "action",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "别长按",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "long_press",
    "timeLimit": 1100,
    "trap": "动作反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "action_medium_076",
    "type": "action",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "别松手",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "quick_tap",
    "timeLimit": 1100,
    "trap": "动作反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "action_medium_077",
    "type": "action",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点一下",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "wait",
    "timeLimit": 1100,
    "trap": "动作反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "action_medium_078",
    "type": "action",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "松手",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "tap",
    "timeLimit": 1100,
    "trap": "动作反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "action_medium_079",
    "type": "action",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "停下",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "tap",
    "timeLimit": 1100,
    "trap": "动作反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "action_medium_080",
    "type": "action",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "别停下",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "quick_tap",
    "timeLimit": 1100,
    "trap": "动作反转",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_081",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点最大的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#FF3D5A",
        "scale": 1.5
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#3483FF",
        "scale": 1
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#00FF9D",
        "scale": 0.5
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "大小陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_082",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点最大的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#FF3D5A",
        "scale": 1.5
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#3483FF",
        "scale": 1
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#00FF9D",
        "scale": 0.5
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "大小陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_083",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点最小的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#3483FF",
        "scale": 0.5
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#FF3D5A",
        "scale": 1
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#00FF9D",
        "scale": 1.5
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "大小陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_084",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点最小的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#3483FF",
        "scale": 0.5
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#FF3D5A",
        "scale": 1
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#00FF9D",
        "scale": 1.5
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "大小陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_085",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点最亮的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#FFFFFF",
        "brightness": "light"
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#FFD600",
        "brightness": "medium"
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#A855F7",
        "brightness": "dark"
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "亮度陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_086",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点最亮的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#FFFFFF",
        "brightness": "light"
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#FFD600",
        "brightness": "medium"
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#A855F7",
        "brightness": "dark"
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "亮度陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_087",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点最暗的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#A855F7",
        "brightness": "dark"
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#FFD600",
        "brightness": "medium"
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#FFFFFF",
        "brightness": "light"
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "亮度陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_088",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点最暗的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#A855F7",
        "brightness": "dark"
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#FFD600",
        "brightness": "medium"
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#FFFFFF",
        "brightness": "light"
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "亮度陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_089",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点最清晰的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#00FF9D",
        "blur": 0
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#FF8A00",
        "blur": 2
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#3483FF",
        "blur": 4
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "清晰度陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_090",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点最清晰的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#00FF9D",
        "blur": 0
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#FF8A00",
        "blur": 2
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#3483FF",
        "blur": 4
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "清晰度陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_091",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点最模糊的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#3483FF",
        "blur": 4
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#FF8A00",
        "blur": 2
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#00FF9D",
        "blur": 0
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "清晰度陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_092",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点最模糊的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#3483FF",
        "blur": 4
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#FF8A00",
        "blur": 2
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#00FF9D",
        "blur": 0
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "清晰度陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_093",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点中间的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#FF3D5A",
        "position": "left"
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#3483FF",
        "position": "middle"
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#00FF9D",
        "position": "right"
      }
    ],
    "correctAction": "btn_1",
    "timeLimit": 1100,
    "trap": "位置陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_094",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点中间的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#FF3D5A",
        "position": "left"
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#3483FF",
        "position": "middle"
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#00FF9D",
        "position": "right"
      }
    ],
    "correctAction": "btn_1",
    "timeLimit": 1100,
    "trap": "位置陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_095",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点左边的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#FF8A00",
        "position": "left"
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#00FF9D",
        "position": "middle"
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#3483FF",
        "position": "right"
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "位置陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_096",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点左边的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#FF8A00",
        "position": "left"
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#00FF9D",
        "position": "middle"
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#3483FF",
        "position": "right"
      }
    ],
    "correctAction": "btn_3",
    "timeLimit": 1100,
    "trap": "位置陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_097",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点右边的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#00FF9D",
        "position": "left"
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#3483FF",
        "position": "middle"
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#FF3D5A",
        "position": "right"
      }
    ],
    "correctAction": "btn_1",
    "timeLimit": 1100,
    "trap": "位置陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_098",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点右边的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#00FF9D",
        "position": "left"
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#3483FF",
        "position": "middle"
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#FF3D5A",
        "position": "right"
      }
    ],
    "correctAction": "btn_1",
    "timeLimit": 1100,
    "trap": "位置陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_099",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点中间颜色不同的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#FF3D5A",
        "position": "left"
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#FFD600",
        "position": "middle"
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#FF3D5A",
        "position": "right"
      }
    ],
    "correctAction": "btn_1",
    "timeLimit": 1100,
    "trap": "颜色陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  },
  {
    "id": "visual_trap_medium_100",
    "type": "visual_trap",
    "difficulty": "medium",
    "difficultyLevel": 3,
    "prompt": "点中间颜色不同的",
    "fontColor": "#FFFFFF",
    "options": [
      {
        "id": "btn_1",
        "label": "按钮1",
        "color": "#FF3D5A",
        "position": "left"
      },
      {
        "id": "btn_2",
        "label": "按钮2",
        "color": "#FFD600",
        "position": "middle"
      },
      {
        "id": "btn_3",
        "label": "按钮3",
        "color": "#FF3D5A",
        "position": "right"
      }
    ],
    "correctAction": "btn_1",
    "timeLimit": 1100,
    "trap": "颜色陷阱",
    "modeTags": [
      "single_level_2",
      "challenge_middle",
      "shadow_challenge"
    ],
    "implementationLevel": "P1"
  }
];
})(window);
