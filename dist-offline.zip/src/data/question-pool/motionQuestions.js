/* Generated from content/questions/motion.json. */
(function (global) {
  "use strict";
  global.MotionQuestionPool = [
  {
    "id": "motion_experimental_001",
    "type": "motion",
    "difficulty": "hard",
    "difficultyLevel": 4,
    "prompt": "向左倾斜",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "tilt_right",
    "timeLimit": 2400,
    "trap": "方向反转",
    "modeTags": [
      "practice_motion"
    ],
    "implementationLevel": "P2",
    "experimental": true
  },
  {
    "id": "motion_experimental_002",
    "type": "motion",
    "difficulty": "hard",
    "difficultyLevel": 4,
    "prompt": "向右倾斜",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "tilt_left",
    "timeLimit": 2400,
    "trap": "方向反转",
    "modeTags": [
      "practice_motion"
    ],
    "implementationLevel": "P2",
    "experimental": true
  },
  {
    "id": "motion_experimental_003",
    "type": "motion",
    "difficulty": "hard",
    "difficultyLevel": 4,
    "prompt": "不要晃动手机",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "shake",
    "timeLimit": 2400,
    "trap": "动作反转",
    "modeTags": [
      "practice_motion"
    ],
    "implementationLevel": "P2",
    "experimental": true
  },
  {
    "id": "motion_experimental_004",
    "type": "motion",
    "difficulty": "hard",
    "difficultyLevel": 4,
    "prompt": "快速晃一下",
    "fontColor": "#FFFFFF",
    "options": null,
    "correctAction": "keep_still",
    "timeLimit": 2400,
    "trap": "动作克制",
    "modeTags": [
      "practice_motion"
    ],
    "implementationLevel": "P2",
    "experimental": true
  }
];
})(window);
